# Crosswalk Detection > 2024-01-07 9:35pm
https://universe.roboflow.com/ai-research-3s2e4/crosswalk-detection-es0cb

Provided by a Roboflow user
License: CC BY 4.0

